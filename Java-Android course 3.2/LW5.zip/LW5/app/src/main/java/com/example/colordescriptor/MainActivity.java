package com.example.colordescriptor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Spinner spinnerColour;
    private TextView textViewDescriptionTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnerColour = findViewById(R.id.spinnerColors);
        textViewDescriptionTemp = findViewById(R.id.textViewDescriptionTemp);
    }

    public void showDescription(View view) {
        int position = spinnerColour.getSelectedItemPosition();
        String description = getDescriptionByPosition(position);
        textViewDescriptionTemp.setText(description);
    }
    private String getDescriptionByPosition(int position){
        String[] description = getResources().getStringArray(R.array.description_of_temp);
        return description[position];
    }
}