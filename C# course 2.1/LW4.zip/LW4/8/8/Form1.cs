﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace _8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            AboutProgram formAboutProgram = new AboutProgram();
            formAboutProgram.Visible = true;

        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            AboutProgram formAboutProgram = new AboutProgram();
            formAboutProgram.Visible = true;
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var sr = new StreamReader(openFileDialog1.FileName);

                textBox2.Text = sr.ReadToEnd();

            }
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var sw = new StreamWriter(saveFileDialog1.FileName);
                sw.WriteLine(textBox2.Text);
                sw.Close();

            }
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }
    }
}
