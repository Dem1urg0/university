﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//tochnost - масштаб

namespace Graficcc
{
    public partial class Oblast : Form
    {
        public Oblast()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                       
            int w = Pole.Width;
            int h = Pole.Height;

            int tochnost = 25;
            int xStart = this.Pole.Width / 2;
            int yStart = this.Pole.Height / 2;
            Graphics g = Pole.CreateGraphics();
            g.Clear(Color.White);
            Font font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));

            g.DrawLine(new Pen(Brushes.Black, 4), new Point(0,yStart), new Point (Pole.Width,yStart));
            g.DrawLine(new Pen(Brushes.Black, 4), new Point(xStart,0), new Point(xStart, Pole.Height));
            g.DrawString("y", font, Brushes.Black, new Point(xStart + 10, 5));
            g.DrawString("x", font, Brushes.Black, new Point(Pole.Width - 10, yStart + 5));

            for (int i = 1; i < (w / 2) / tochnost; i++)
            {
                g.DrawLine(new Pen(Brushes.Black, 2), new Point (xStart - i * tochnost, 0), new Point(xStart - i * tochnost, h));
                g.DrawLine(new Pen(Brushes.Black, 2), new Point (xStart + i * tochnost, 0), new Point(xStart + i * tochnost, h));
            }

            for (int i = 1; i < (h / 2); i++)
            {
                g.DrawLine(new Pen (Brushes.Black, 2), new Point(0, yStart - i * tochnost), new Point(w, yStart - i * tochnost));
                g.DrawLine(new Pen(Brushes.Black, 2), new Point(0, yStart + i * tochnost), new Point(w, yStart + i * tochnost));
            }

            int steps = (Int32)(w / tochnost / 0.1);
            Point prev;
            double x0 = (-1) * ((w / tochnost) / 2);
            double prevX = 0 - w / tochnost;
            {
                double y1 = Math.Abs(x0);
                prev = new Point(xStart + (int)(x0 * tochnost), yStart - (int)(Math.Abs(x0) * tochnost));
            }

            for (int i = 1; i < steps; i++)
            {
                double nX = x0 + i * 0.1;
                double nY = Math.Abs(nX);
                Point n = new Point(xStart + (int)(nX * tochnost), yStart - (int)(nY * tochnost));
                g.DrawLine(new Pen(Brushes.Red, 2), prev, n);
                prev = n;
            }
        }

        private void Oblast_Load(object sender, EventArgs e)
        {

        }
    }
}
